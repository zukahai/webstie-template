<?php
    $servername = "localhost";

    // host

    $username = "id18943592_php";
    $password = "12345678910Aa@";
    $dbname = "id18943592_minhtri";

    // localhost xampp

    // $username = "root";
    // $password = "";
    // $dbname = "php";
?>